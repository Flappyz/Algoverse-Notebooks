# Slope Game
### The original slope game! 
## Links:
### [Slope Game (Bigfoot9999)](https://bigfoot9999.github.io/Slope-Game/)
### [Bigfoot's Game Shack (v3)](https://bgs.pages.dev)

<img src="https://komarev.com/ghpvc/?username=Bigfoot9999&label=Repo Visitors&color=001eff&style=flat" alt="Bigfoot9999" /> 
